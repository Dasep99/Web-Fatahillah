<?php $__env->startSection('isicontent'); ?>
    <div id="portfolio" class="portfolio-area area-padding fix">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mt-4">
                    <div class="section-headline text-center">
                        <h2>Siswa SMPIT Fatahillah</h2>
                    </div>
                </div>
            </div>


            <div class="row awesome-project-content portfolio-container">

                <!-- portfolio-item start -->
                <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-4 col-xs-12 portfolio-item filter-app portfolio-item">
                        <div class="single-awesome-project">
                            <div class="awesome-img">
                                <a href="#"><img src="<?php echo e(asset('uploads/' . $data->gambar)); ?>" alt="" /></a>
                                <div class="add-actions text-center">
                                    <div class="project-dec">

                                        <h5><?php echo e($data->nama); ?></h5>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- portfolio-item end -->


            </div>
            <?php echo e($siswa->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ITC - NETLAB - 01\Documents\Project\webfatahillah\resources\views/frontend/profil/siswa.blade.php ENDPATH**/ ?>