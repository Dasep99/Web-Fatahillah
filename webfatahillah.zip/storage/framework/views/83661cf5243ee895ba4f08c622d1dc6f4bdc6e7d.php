<footer>
    <div class="footer-area">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="footer-content">
                        <div class="footer-head">
                            <div class="footer-logo">
                                <h2>SMP IT <span>FATAHILLAH</span></h2>
                            </div>

                            <p>
                                Jl. Serbaguna No.49, Jadimulya, Kec. Gunungjati, Kabupaten Cirebon, Jawa Barat 45151</p>

                        </div>
                    </div>
                </div>
                <!-- end single footer -->
                <div class="col-md-4">
                    <div class="footer-content">
                        <div class="footer-head">
                            <h4>Kontak</h4>

                            <div class="footer-contacts">
                                <p><span>Tel:</span> 0231-205713</p>
                                <p><span>Email:</span> smpit.fatahillah@gmail.com</p>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- end single footer -->
                <div class="col-md-4 ">
                    <div class="footer-content">
                        <div class="footer-head">
                            <div class="footer-logo">
                                <h4>Sosial Media</h4>
                            </div>


                            <div class="footer-icons">
                                <ul>
                                    <li>
                                        <a href="https://www.facebook.com/profile.php?id=100088038758714"><i
                                                class="bi bi-facebook"></i></a>
                                    </li>

                                    <li>
                                        <a href="https://www.instagram.com/smpitfatahillahcirebon/"><i
                                                class="bi bi-instagram"></i></a>
                                    </li>
                                    <li>
                                        <a href="https://www.youtube.com/@smpitfatahillahcirebon9148"><i
                                                class="bi bi-youtube"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-area-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="copyright text-center">
                        <p>
                            &copy; Copyright SMPIT FATHILLAH
                        </p>
                    </div>

                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\ITC - NETLAB - 01\Documents\Project\webfatahillah\resources\views/layouts/footer.blade.php ENDPATH**/ ?>