<footer class="footer">
    <div class="container-fluid">
        <nav class="pull-left">
            <ul class="nav">

        </nav>
        <div class="copyright ml-auto">
            SMP IT FATAHILLAH
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\ITC - NETLAB - 01\Documents\Project\webfatahillah\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>