<?php $__env->startSection('isicontent'); ?>
    <main id="main">

        <!-- ======= Blog Page ======= -->
        <div class="blog-page area-padding">
            <div class="container">
                <div class="row">

                    <div class="col-md-8 col-sm-8 col-xs-12">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="single-blog">
                                    <div class="single-blog-img">
                                        <a>
                                            <img class="mt-3" src="<?php echo e(asset('uploads/' . $sambutan->gambar_sambutan)); ?>"
                                                alt="">
                                        </a>
                                    </div>
                                    <div class="blog-meta">

                                        <span class="date-type">
                                            <i class="bi bi-calendar"></i><?php echo e($sambutan->created_at); ?>

                                        </span>
                                        <hr>
                                    </div>
                                    <div class="blog-text">
                                        <h4>
                                            <?php echo e($sambutan->judul); ?>

                                        </h4>
                                        <p>
                                            <?php echo $sambutan->deskripsi; ?>

                                        </p>
                                    </div>

                                </div>
                            </div>

                            <!-- End single blog -->

                        </div>
                    </div>

                    <div class="col-lg-4 col-md-4 mt-2">
                        <div class="page-head-blog">
                            <div class="single-blog-page">
                                <!-- recent start -->
                                <div class="left-blog">
                                    <h4>Informasi Terbaru</h4>
                                    <div class="recent-post">
                                        <!-- start single post -->
                                        <?php $__currentLoopData = $informasiterbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="recent-single-post">
                                                <div class="post-img">
                                                    <a href="#">
                                                        <img src="<?php echo e(asset('uploads/' . $data->gambar_informasi)); ?>"
                                                            alt="">
                                                    </a>
                                                </div>
                                                <div class="pst-content mt-2">
                                                    <p><a href="<?php echo e(route('detail-informasi', $data->id)); ?>">
                                                            <?php echo e($data->judul); ?> </a>
                                                    </p>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <!-- End single post -->

                                    </div>
                                </div>
                                <!-- recent end -->
                            </div>


                        </div>
                    </div>

                    <!-- Start single blog -->

                </div>
            </div>
        </div><!-- End Blog Page -->

    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ITC - NETLAB - 01\Documents\Project\webfatahillah\resources\views/frontend/detail/detailsambutan.blade.php ENDPATH**/ ?>