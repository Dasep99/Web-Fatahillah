<?php $__env->startSection('isicontent'); ?>


        <!-- ======= Blog Page ======= -->
        <!doctype html>
        <html lang="en">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="style.css">
            <title>Bootstrap demo</title>

            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        </head>
        <body>
        <br>
        <br>
        <br>
        <br>
        <div class="container">
           <div class="row">

               <div  class="embed-responsive embed-responsive-16by9">
                   <video class="embed-responsive-item" src="<?php echo e(asset('uploads/' . $video->video)); ?>" controls autoplay></video>
               </div>
               <div class="blog-meta">
                                        <span class="date-type">
                                            <i class="bi bi-calendar"></i><?php echo e($video->created_at); ?>

                                        </span>
                   <hr>
                   <h4>
                       <?php echo e($video->judul); ?>

                   </h4>
                   <p>
                       <?php echo $video->deskripsi; ?>

                   </p>
               </div>

           </div>
        </div>

        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        </body>
        </html>















































































        <!-- End Blog Page -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ITC - NETLAB - 01\Documents\Project\webfatahillah\resources\views/frontend/detail/detailvideo.blade.php ENDPATH**/ ?>