<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="d-flex align-items-center">
                    <h4 class="card-title">Detail Tentang Informasi</h4>


                    <a href="<?php echo e(route('admintentang.index')); ?>" class="btn btn-warning btn-sm ml-auto"><i class=""></i>
                        Back</a>

                </div>
            </div>
            <div class="card-body">

                <main id="main">

                    <!-- ======= Blog Page ======= -->
                    <div class="blog-page area-padding">
                        <div class="container">
                            <div class="row">

                                <div class="col-md-8 col-sm-8 col-xs-12">
                                    <div class="row">
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="single-blog">
                                                <div class="single-blog-img">
                                                    <a href="blog-details.html">
                                                        <img width="600" class="mt-3 mb-2"
                                                            src="<?php echo e(asset('uploads/' . $tentang->gambar_tentang)); ?>"
                                                            alt="">
                                                    </a>
                                                </div>
                                                <div class="blog-meta">

                                                    <span class="date-type">
                                                        <i class="bi bi-calendar"></i><?php echo e($tentang->created_at); ?>

                                                    </span>
                                                    <hr>
                                                </div>
                                                <div class="blog-text">
                                                    <h4>
                                                        <?php echo e($tentang->judul); ?>

                                                    </h4>
                                                    <p>
                                                        <?php echo $tentang->deskripsi; ?>

                                                    </p>
                                                </div>

                                            </div>
                                        </div>

                                        <!-- End single blog -->

                                    </div>
                                </div>



                                <!-- Start single blog -->

                            </div>
                        </div>
                    </div><!-- End Blog Page -->

                </main><!-- End #main -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.includes.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ITC - NETLAB - 01\Documents\Project\webfatahillah\resources\views/admin/tentang/detailtentang.blade.php ENDPATH**/ ?>