<footer class="footer">
    <div class="container-fluid">
        <nav class="pull-left">
            <ul class="nav">

        </nav>
        <div class="copyright ml-auto">
            SMP IT FATAHILLAH
        </div>
    </div>
</footer>
